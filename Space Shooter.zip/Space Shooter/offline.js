﻿{
	"version": 1506077411,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-2.1.1.min.js",
		"offlineClient.js",
		"images/pesawat-sheet0.png",
		"images/peluru-sheet0.png",
		"images/meteor2-sheet0.png",
		"images/particles.png",
		"images/ledakanmeteor.png",
		"images/ledakanpesawat.png",
		"images/bgscore-sheet0.png",
		"images/gameover-sheet0.png",
		"images/background-sheet0.png",
		"media/sounddestroy.ogg",
		"media/soundpeluru.ogg",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png"
	]
}